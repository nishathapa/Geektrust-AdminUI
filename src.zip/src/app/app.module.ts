import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MatTableModule} from '@angular/material/table';
// import { MatTableDataSource } from '@angular/material/table'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeTableComponent } from './employee-table/employee-table.component';
import { HttpClientModule } from '@angular/common/http';
import { DataServiceService } from './data-service.service';
import { MatPaginatorModule } from '@angular/material/paginator';
// import { MatTable } from '@angular/material/table';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeTableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MatTableModule,
    MatPaginatorModule
    // MatTableDataSource
  ],
  providers: [DataServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
