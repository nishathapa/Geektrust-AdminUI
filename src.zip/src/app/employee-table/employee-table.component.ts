import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';  
import { throwError } from 'rxjs';
import { DataServiceService } from '../data-service.service';
import { catchError } from 'rxjs/operators';
import { MatPaginator } from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import {PageEvent} from '@angular/material/paginator';


export interface employee {
  id: number;
  name: string;
  email: any;
  role: string;
}


@Component({
  selector: 'app-employee-table',
  templateUrl: './employee-table.component.html',
  styleUrls: ['./employee-table.component.css']
})


export class EmployeeTableComponent implements OnInit {
  employeeData:employee[] =[];
  length = 100;
  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 25, 100];
  pageEvent: PageEvent = new PageEvent;

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }

  constructor(private dataService: DataServiceService){}

  displayedColumns: string[] = ['id', 'name', 'email', 'role'];
  dataSource = this.employeeData;
  ngOnInit(): void{
    this.getData();
  }

  getData() {
    this.dataService.getData().subscribe((data: any) => {
      this.employeeData = data;
      console.log("EMPLOYEE", this.employeeData)
      this.dataSource = this.employeeData;
    }), catchError(error => {
      return throwError('Something went wrong')
    })
  }
    
}

